//
//  GoalStruct.swift
//  fews
//
//  Created by  오정아 on 2022/07/07.
//

import Foundation

struct GoalStruct {
    var title: String
    var timer: Int
    var achievetimer: Int
    var timerOnOff: Bool
}
